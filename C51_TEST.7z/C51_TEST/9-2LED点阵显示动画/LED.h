#ifndef __LED_H__
#define __LED_H__

void _74HC595_WriteByte(unsigned char byet);
void LED(unsigned char Column,Data);
void LED_Init();

#endif
