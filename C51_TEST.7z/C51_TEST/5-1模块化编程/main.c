#include <REGX51.H>
#include "Delay.h"
#include "Shu.h"

void main(){
	while(1){
		
		Shu(1,3);
		Shu(2,6);
		Shu(3,7);
		Shu(4,1);
		Shu(5,8);
		Shu(6,5);
	}
}
