#ifndef __DS18B20_H__
#define __DS18B20_H__

void DS18B20_ConvertT();
float DS18B20_ReadT();

#endif