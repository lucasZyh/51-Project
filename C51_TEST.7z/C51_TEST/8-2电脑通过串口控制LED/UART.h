#ifndef __UARY_H__
#define __UARY_H__

void UART_Init();
void UART_SendByte(unsigned char byet);

#endif
