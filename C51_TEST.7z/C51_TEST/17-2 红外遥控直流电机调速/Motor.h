#ifndef __MOTOR_H__
#define __MOTOR_H__

void Motor_Initn();
void Motor_SetSpeed(unsigned char speed);

#endif