#ifndef __SHU_H__
#define __SHU_H__

void Shu(unsigned char location, number);

#endif