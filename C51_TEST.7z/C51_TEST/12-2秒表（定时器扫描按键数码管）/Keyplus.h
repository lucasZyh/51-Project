#ifndef __KEYPLUS_H__
#define __KEYPLUS_H__

unsigned char Key();
void Key_Loop();

#endif
