#ifndef __SHUPLUS_H__
#define __SHUPLUS_H__

void Shu_Scan(unsigned char location, number);
void Shu_SetBuf(unsigned char location, number);
void Shu_Loop();

#endif