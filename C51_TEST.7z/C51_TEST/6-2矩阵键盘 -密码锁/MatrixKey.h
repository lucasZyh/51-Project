#ifndef __MATRIXKEY_H__
#define __MATRIXKEY_H__

void Delay(unsigned int t);unsigned char MatrixKey();
#endif
